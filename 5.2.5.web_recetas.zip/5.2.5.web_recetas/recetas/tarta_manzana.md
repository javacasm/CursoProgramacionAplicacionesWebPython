---
Title: Receta de Tarta de Manzana
Date: 2025-08-15
Category: Postres
Tags: manzana, horno
---

# Ingredientes
- 3 manzanas
- 1 lámina de hojaldre
- 100g azúcar
- Canela al gusto

## Preparación
1. Pelar y cortar las manzanas.
2. ...

![Tarta de manzana](images/tarta.jpg)