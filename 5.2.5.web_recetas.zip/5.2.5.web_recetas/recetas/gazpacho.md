---
Title: Receta de Gazpacho
Date: 2025-08-20
Category: Sopa
Tags: tomate, sopa fría
---

# Ingredientes
- 3 tomates maduros
- 1 pepino
- 1 pimiento verde
- ...

![Gazpacho](images/gazpacho.jpg)